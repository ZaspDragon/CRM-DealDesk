# DealDesk — Screenshot Analyzer (GitHub Pages)

Upload a listing screenshot, OCR it in the browser, and compute:
- Best deal structure suggestion
- Projected profit (rough)
- Buy-to-profit ratio
- MAO (default 70% rule)
- Buyer-ready message you can copy/paste

## How to deploy FREE on GitHub Pages

1. Create a new GitHub repo (example: `dealdesk`)
2. Upload these files to the repo (or drag/drop the zip contents)
3. In GitHub:
   - **Settings → Pages**
   - Source: **Deploy from a branch**
   - Branch: **main** / folder: **/(root)**
4. Wait 1–2 minutes, then your site URL appears under Pages.

## Notes
- OCR runs via **Tesseract.js** in the browser (no server).
- For best OCR: crop your screenshot tight around the numbers before uploading.
- CRM is stored in **localStorage** in your browser.

## Disclaimer
This is quick deal triage. Verify all numbers before sending offers or marketing deals.
