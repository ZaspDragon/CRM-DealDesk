// DealDesk — static OCR + deal math (GitHub Pages friendly)
// Everything runs in-browser. OCR via Tesseract.js CDN.

const $ = (id) => document.getElementById(id);

const state = {
  ocrText: "",
  lastComputed: null,
};

function money(n){
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  const sign = n < 0 ? "-" : "";
  const v = Math.abs(n);
  return sign + "$" + v.toLocaleString(undefined, {maximumFractionDigits: 0});
}

function pct(n){
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return (n*100).toFixed(1) + "%";
}

function numFromInput(id){
  const raw = ($(id).value || "").toString().replace(/[$,\s]/g,"");
  const n = parseFloat(raw);
  return Number.isFinite(n) ? n : null;
}

// Heuristic parse: find likely money amounts near keywords
function extractMoneyNear(text, keywords){
  const t = text.toLowerCase();
  for (const kw of keywords){
    const idx = t.indexOf(kw);
    if (idx !== -1){
      const window = text.slice(Math.max(0, idx-40), Math.min(text.length, idx+80));
      const m = window.match(/\$?\s?([0-9]{1,3}(?:[, ][0-9]{3})+|[0-9]{2,})(?:\.[0-9]{1,2})?/);
      if (m){
        const cleaned = m[1].replace(/[ ,]/g,"");
        const n = parseFloat(cleaned);
        if (Number.isFinite(n)) return n;
      }
    }
  }
  return null;
}

function extractPercentNear(text, keywords){
  const t = text.toLowerCase();
  for (const kw of keywords){
    const idx = t.indexOf(kw);
    if (idx !== -1){
      const window = text.slice(Math.max(0, idx-30), Math.min(text.length, idx+60));
      const m = window.match(/([0-9]{1,2}(?:\.[0-9])?)\s?%/);
      if (m){
        const n = parseFloat(m[1]);
        if (Number.isFinite(n)) return n;
      }
    }
  }
  return null;
}

function suggestStructures({ask, arv, repairs, rent, payment, minCf, minEq}){
  // Scores: higher is better
  const suggestions = [];

  const eqPct = (ask && arv) ? ( (arv - ask) / arv ) : null;
  const cashflow = (rent !== null && payment !== null) ? (rent - payment) : null;

  // SubTo: needs payment + rent and positive cashflow; also some equity (or at least not upside-down)
  let subScore = 0;
  if (payment !== null) subScore += 1;
  if (cashflow !== null){
    if (cashflow >= minCf) subScore += 3;
    else if (cashflow > 0) subScore += 2;
    else subScore -= 2;
  }
  if (eqPct !== null){
    if (eqPct*100 >= minEq) subScore += 2;
    else if (eqPct > 0) subScore += 1;
    else subScore -= 2;
  }
  suggestions.push({name:"Subject-To (SubTo)", score:subScore});

  // Seller finance: if motivation high or asking flexible; without that signal, moderate score
  const mot = parseInt($("motivation").value, 10);
  let sfScore = 1 + (mot >= 4 ? 2 : 0);
  if (eqPct !== null && eqPct > 0.2) sfScore += 1;
  suggestions.push({name:"Seller Financing", score:sfScore});

  // Wholesale: best when big spread between ARV and ask and repairs are manageable
  let whScore = 0;
  if (ask !== null && arv !== null){
    const spread = arv - ask - (repairs||0);
    if (spread > 40000) whScore += 4;
    else if (spread > 25000) whScore += 3;
    else if (spread > 15000) whScore += 2;
    else if (spread > 5000) whScore += 1;
    else whScore -= 2;
  }
  if (mot >= 4) whScore += 1;
  suggestions.push({name:"Wholesale / Assignment", score:whScore});

  // Flip: needs enough profit after costs
  let flipScore = 0;
  if (ask !== null && arv !== null){
    const sellCosts = arv * (numFromInput("sellPct")/100);
    const hold = numFromInput("holdFlat") || 0;
    const profit = arv - (ask + (repairs||0) + sellCosts + hold);
    if (profit > 40000) flipScore += 4;
    else if (profit > 25000) flipScore += 3;
    else if (profit > 15000) flipScore += 2;
    else if (profit > 5000) flipScore += 1;
    else flipScore -= 2;
  }
  suggestions.push({name:"Fix & Flip", score:flipScore});

  // Novation: agent-listed but with spread; treat similar to wholesale/flip
  let novScore = 1 + (mot >= 4 ? 1 : 0) + (whScore >= 2 ? 1 : 0);
  suggestions.push({name:"Novation (agent-friendly)", score:novScore});

  // Lease option: when cashflow is decent but equity isn't huge
  let loScore = 0;
  if (cashflow !== null){
    if (cashflow >= minCf) loScore += 3;
    else if (cashflow > 0) loScore += 2;
    else loScore -= 1;
  }
  if (eqPct !== null && eqPct < 0.15) loScore += 1;
  suggestions.push({name:"Lease Option", score:loScore});

  suggestions.sort((a,b)=>b.score-a.score);
  return {best:suggestions[0]?.name || "—", suggestions, eqPct, cashflow};
}

function compute(){
  const ask = numFromInput("ask");
  const arv = numFromInput("arv");
  const repairs = numFromInput("repairs") || 0;
  const rent = numFromInput("rent");
  const payment = numFromInput("payment");

  const maoPct = (numFromInput("maoPct") ?? 70) / 100;
  const sellPct = (numFromInput("sellPct") ?? 8) / 100;
  const holdFlat = numFromInput("holdFlat") ?? 6000;
  const whFee = numFromInput("whFee") ?? 10000;
  const minCf = numFromInput("minCf") ?? 250;
  const minEq = numFromInput("minEq") ?? 15;

  // 70% rule MAO
  const mao = (arv !== null) ? Math.max(0, (arv * maoPct) - repairs) : null;

  // Flip profit (rough)
  const sellCosts = (arv !== null) ? (arv * sellPct) : null;
  const flipProfit = (ask !== null && arv !== null && sellCosts !== null)
    ? (arv - (ask + repairs + sellCosts + holdFlat))
    : null;

  // Buy-to-profit ratio (lower is better). If profit <=0, show infinity-ish.
  const bpr = (ask !== null && flipProfit !== null)
    ? (flipProfit > 0 ? (ask / flipProfit) : null)
    : null;

  const {best, suggestions, eqPct, cashflow} = suggestStructures({ask, arv, repairs, rent, payment, minCf, minEq});

  $("bestStructure").textContent = best;
  $("profit").textContent = money(flipProfit);
  $("bpr").textContent = (bpr === null) ? "—" : bpr.toFixed(2);
  $("equity").textContent = (eqPct === null) ? "—" : ( (eqPct*100).toFixed(1) + "%" );
  $("cashflow").textContent = (cashflow === null) ? "—" : (money(cashflow) + " /mo");
  $("offer").textContent = (mao === null) ? "—" : ("MAO ≈ " + money(mao));

  const dealName = ($("dealName").value || "Deal").trim();
  const occ = $("occupied").value;

  const buyerLines = [];
  buyerLines.push(`🏠 DEAL: ${dealName}`);
  if (ask !== null) buyerLines.push(`Asking: ${money(ask)}`);
  if (arv !== null) buyerLines.push(`ARV: ${money(arv)}`);
  if (repairs) buyerLines.push(`Repairs est.: ${money(repairs)}`);
  if (eqPct !== null) buyerLines.push(`Equity: ${(eqPct*100).toFixed(1)}%`);
  if (rent !== null) buyerLines.push(`Market Rent: ${money(rent)}/mo`);
  if (payment !== null) buyerLines.push(`Est. Pmt (if SubTo): ${money(payment)}/mo`);
  if (cashflow !== null) buyerLines.push(`Cashflow (Rent−Pmt): ${money(cashflow)}/mo`);
  buyerLines.push(`Best Structure: ${best}`);
  if (mao !== null) buyerLines.push(`Suggested Offer (MAO): ${money(mao)}`);
  if (flipProfit !== null) buyerLines.push(`Projected Flip Profit (rough): ${money(flipProfit)}`);
  if (bpr !== null) buyerLines.push(`Buy-to-Profit Ratio: ${bpr.toFixed(2)} (lower = better)`);
  buyerLines.push(`Occupied: ${occ}`);
  buyerLines.push(`Notes: ${$("notes").value || "—"}`);

  // Add a simple wholesale suggestion
  if (best.includes("Wholesale") && mao !== null && whFee){
    const buyerPrice = mao + whFee;
    buyerLines.push(`Buyer Price Target (MAO + fee): ${money(buyerPrice)}`);
  }

  $("buyerMsg").value = buyerLines.join("\n");

  state.lastComputed = {
    date: new Date().toISOString(),
    dealName,
    ask, arv, repairs,
    best,
    flipProfit,
    mao,
    bpr,
    stage: "new",
  };
}

async function runOcr(){
  const file = $("file").files?.[0];
  if (!file){ alert("Pick an image first."); return; }

  $("bar").style.width = "0%";
  $("ocrText").textContent = "Running OCR…";

  const worker = await Tesseract.createWorker("eng");
  await worker.setParameters({
    tessedit_char_whitelist: "0123456789$.,%:/-ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ",
  });

  const { data } = await worker.recognize(file, {
    logger: (m) => {
      if (m.status === "recognizing text" && m.progress != null){
        $("bar").style.width = Math.round(m.progress * 100) + "%";
      }
    }
  });

  await worker.terminate();

  const text = (data.text || "").trim();
  state.ocrText = text;
  $("ocrText").textContent = text || "(No text detected)";

  // Auto-fill guesses
  const ask = extractMoneyNear(text, ["price", "list", "asking", "purchase", "value"]);
  const repairs = extractMoneyNear(text, ["repairs", "rehab", "renov", "fix", "work"]);
  const payment = extractMoneyNear(text, ["payment", "pmt", "mortgage", "principal", "escrow"]);
  const rent = extractMoneyNear(text, ["rent", "rental", "tenant", "lease"]);
  // Equity sometimes shown as percent
  const equityPct = extractPercentNear(text, ["equity"]);

  if (ask !== null && $("ask").value === "") $("ask").value = Math.round(ask).toString();
  if (repairs !== null && $("repairs").value === "") $("repairs").value = Math.round(repairs).toString();
  if (payment !== null && $("payment").value === "") $("payment").value = Math.round(payment).toString();
  if (rent !== null && $("rent").value === "") $("rent").value = Math.round(rent).toString();

  // If equity % detected and ARV missing, approximate ARV from ask
  if (equityPct !== null && $("arv").value === "" && $("ask").value !== ""){
    const a = parseFloat($("ask").value);
    const eq = equityPct/100;
    // equity% = (arv-ask)/arv => ask = arv*(1-eq) => arv = ask/(1-eq)
    const arvGuess = a / (1 - eq);
    if (Number.isFinite(arvGuess)) $("arv").value = Math.round(arvGuess).toString();
  }
}

function loadPreview(){
  const file = $("file").files?.[0];
  if (!file) return;
  const url = URL.createObjectURL(file);
  const img = $("img");
  img.src = url;
  img.style.display = "block";
}

function crmGet(){
  try{ return JSON.parse(localStorage.getItem("deals_crm") || "[]"); }
  catch{ return []; }
}
function crmSet(items){
  localStorage.setItem("deals_crm", JSON.stringify(items));
}
function crmRender(){
  const stage = $("filterStage").value;
  const items = crmGet().filter(x => stage==="all" ? true : x.stage===stage);

  const tbody = $("crm").querySelector("tbody");
  tbody.innerHTML = "";
  for (const it of items){
    const tr = document.createElement("tr");
    const d = new Date(it.date);
    tr.innerHTML = `
      <td>${d.toLocaleDateString()}</td>
      <td>${escapeHtml(it.dealName || "")}</td>
      <td>${money(it.ask)}</td>
      <td>${money(it.arv)}</td>
      <td>${money(it.repairs)}</td>
      <td>${escapeHtml(it.best || "")}</td>
      <td>${money(it.flipProfit)}</td>
      <td>
        <select data-id="${it.id}" class="stageSel">
          ${["new","review","sent","closed","dead"].map(s=>`<option value="${s}" ${it.stage===s?"selected":""}>${s}</option>`).join("")}
        </select>
      </td>
      <td><button class="btn secondary small" data-del="${it.id}">Delete</button></td>
    `;
    tbody.appendChild(tr);
  }

  tbody.querySelectorAll(".stageSel").forEach(sel=>{
    sel.addEventListener("change", (e)=>{
      const id = e.target.getAttribute("data-id");
      const itemsAll = crmGet();
      const idx = itemsAll.findIndex(x=>x.id===id);
      if (idx>=0){ itemsAll[idx].stage = e.target.value; crmSet(itemsAll); crmRender(); }
    });
  });

  tbody.querySelectorAll("button[data-del]").forEach(btn=>{
    btn.addEventListener("click", ()=>{
      const id = btn.getAttribute("data-del");
      const itemsAll = crmGet().filter(x=>x.id!==id);
      crmSet(itemsAll); crmRender();
    });
  });
}

function escapeHtml(s){
  return (s||"").replace(/[&<>"']/g, (c)=>({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
}

function saveDeal(){
  if (!state.lastComputed){ compute(); }
  if (!state.lastComputed){ alert("Compute first."); return; }

  const items = crmGet();
  const id = crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2);
  items.unshift({...state.lastComputed, id});
  crmSet(items);
  crmRender();
  alert("Saved to CRM.");
}

function exportCsv(){
  const items = crmGet();
  const headers = ["date","dealName","ask","arv","repairs","best","flipProfit","mao","bpr","stage"];
  const rows = [headers.join(",")];
  for (const it of items){
    const row = headers.map(h => {
      const v = it[h] ?? "";
      return `"${String(v).replace(/"/g,'""')}"`;
    }).join(",");
    rows.push(row);
  }
  const blob = new Blob([rows.join("\n")], {type:"text/csv"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "deals_crm.csv";
  a.click();
  URL.revokeObjectURL(url);
}

function clearAll(){
  ["dealName","ask","arv","repairs","rent","payment","notes"].forEach(id => $(id).value="");
  $("ocrText").textContent = "";
  $("bar").style.width = "0%";
  $("buyerMsg").value = "";
  ["bestStructure","profit","bpr","equity","cashflow","offer"].forEach(id => $(id).textContent="—");
  state.lastComputed = null;
}

function copyMsg(){
  const txt = $("buyerMsg").value;
  navigator.clipboard.writeText(txt).then(()=>alert("Copied."), ()=>alert("Copy failed — select and copy manually."));
}

function wipeCrm(){
  if (!confirm("Wipe all CRM deals?")) return;
  localStorage.removeItem("deals_crm");
  crmRender();
}

document.addEventListener("DOMContentLoaded", ()=>{
  $("file").addEventListener("change", loadPreview);
  $("runOcr").addEventListener("click", runOcr);
  $("compute").addEventListener("click", compute);
  $("saveDeal").addEventListener("click", saveDeal);
  $("exportCsv").addEventListener("click", exportCsv);
  $("clearAll").addEventListener("click", clearAll);
  $("copyMsg").addEventListener("click", copyMsg);
  $("filterStage").addEventListener("change", crmRender);
  $("wipeCrm").addEventListener("click", wipeCrm);
  crmRender();
});
